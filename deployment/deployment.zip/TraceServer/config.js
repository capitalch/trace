var config = {
    "graphql": {
		"development": "http://localhost:5000",
		"production1": "http://localhost:5000",
		"production":"http://stage.cloudjiffy.net",
		"endPoint": "graphql"
	}
}