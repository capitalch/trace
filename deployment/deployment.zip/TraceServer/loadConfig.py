import simplejson as json
with open('config.json') as f:
    cfg = json.load(f)